package com.smetsalud.app.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "afiliados")
public class Afiliados implements Serializable{
	
	@Id
	@Column(name="documento", nullable=false, unique = true)
	private Long id;
	
	@Column(nullable=false, length = 150)
	private String tipoDocumento;
	
	@Column(nullable=false, length = 150)
	private String name;
	
	@Column(nullable=false, length = 30)
	private String fechaNacimiento;
	
	@Column(nullable=false, length = 20)
	private String fechaIngreso;
    
	@Column(nullable=true, length = 3)
	private Long edad;
	
	@Column(nullable=false, length = 20)
	private String direccion;
	
	@Column(nullable=true, length = 3)
	private Long telefono;
	
	@Column(nullable=true, length = 1)
	private Long nivelSisben;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(String fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	public Long getEdad() {
		return edad;
	}

	public void setEdad(Long edad) {
		this.edad = edad;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public Long getTelefono() {
		return telefono;
	}

	public void setTelefono(Long telefono) {
		this.telefono = telefono;
	}

	public Long getNivelSisben() {
		return nivelSisben;
	}

	public void setNivelSisben(Long nivelSisben) {
		this.nivelSisben = nivelSisben;
	}
	
		
	
	
}
