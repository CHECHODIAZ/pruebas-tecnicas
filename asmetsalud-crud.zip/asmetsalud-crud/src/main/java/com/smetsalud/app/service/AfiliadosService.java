package com.smetsalud.app.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.smetsalud.app.entity.Afiliados;

public interface AfiliadosService {
	
	public Iterable<Afiliados> findAll();
	
	public Page<Afiliados> findAll(Pageable pageable);
	
	public Optional<Afiliados> findById(Long id);
	
	public Afiliados save(Afiliados afiliados);
	
	public void deleteById(Long id);

}
