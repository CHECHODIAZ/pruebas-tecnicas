package com.smetsalud.app.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smetsalud.app.entity.Afiliados;
import com.smetsalud.app.service.AfiliadosService;

@RestController
@RequestMapping("/api/afiliados")
public class AfiliadosControlller {
    @Autowired
    private AfiliadosService afiliados;
    
    //Create new afiliado
    @PostMapping
    public ResponseEntity<?> create(@RequestBody Afiliados afiliado){
    	
    	return ResponseEntity.status(HttpStatus.CREATED).body(afiliados.save(afiliado));
    	
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<?> read (@PathVariable(value = "id") Long afiliadoId){
    	Optional<Afiliados> opafiliado = afiliados.findById(afiliadoId);
    	
    	if(!opafiliado.isPresent()) {
    		return ResponseEntity.notFound().build();
    	}
    	
    	return ResponseEntity.ok(opafiliado);
    }
    // Update a afiliado
    @PutMapping("/{id}")
    public ResponseEntity<?> update (@RequestBody Afiliados afiliadoDatails, @PathVariable (value = "id") Long afiliadoId){
    	 Optional<Afiliados> afiliado = afiliados.findById(afiliadoId);
    	 
    	 if(!afiliado.isPresent()) {
    		 return ResponseEntity.notFound().build();
    	 }
    	 
    	 afiliado.get().setName(afiliadoDatails.getName());
    	 afiliado.get().setDireccion(afiliadoDatails.getDireccion());
    	 afiliado.get().setEdad(afiliadoDatails.getEdad());
    	 afiliado.get().setFechaIngreso(afiliadoDatails.getFechaIngreso());
    	 afiliado.get().setFechaNacimiento(afiliadoDatails.getFechaNacimiento());
    	 afiliado.get().setId(afiliadoDatails.getId());
    	 afiliado.get().setTipoDocumento(afiliadoDatails.getTipoDocumento());
    	 afiliado.get().setNivelSisben(afiliadoDatails.getNivelSisben());
    	 afiliado.get().setTelefono(afiliadoDatails.getTelefono());
    	 
    	 return ResponseEntity.status(HttpStatus.CREATED).body(afiliados.save(afiliado.get()));
    	 
    }
    
    //Delete a afiliado
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete (@PathVariable(value = "id") Long afiliadoId) {
    	if(!afiliados.findById(afiliadoId).isPresent()) {
    		return ResponseEntity.notFound().build();
    	}
    	
    	afiliados.deleteById(afiliadoId);
    	return ResponseEntity.ok().build();
    }
    
    // Read all campaigns
    @GetMapping
    public List<Afiliados> readAll(){
    	List<Afiliados> afiliads = StreamSupport
    			.stream(afiliados.findAll().spliterator(), false)
    			.collect(Collectors.toList());
    	
    	return afiliads;
    }
    
    
   
    
}
