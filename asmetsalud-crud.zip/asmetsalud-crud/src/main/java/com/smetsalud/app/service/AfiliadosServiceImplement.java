package com.smetsalud.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smetsalud.app.entity.Afiliados;
import com.smetsalud.app.repository.AfiliadosRepository;

@Service
public class AfiliadosServiceImplement implements AfiliadosService {
	
	@Autowired
	private AfiliadosRepository afiliadosrepo;

	@Override
	@Transactional(readOnly = true)
	public Iterable<Afiliados> findAll() {
		
		return afiliadosrepo.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<Afiliados> findAll(Pageable pageable) {
		
		return afiliadosrepo.findAll(pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Afiliados> findById(Long id) {
		
		return afiliadosrepo.findById(id);
	}

	@Override
	@Transactional
	public Afiliados save(Afiliados afiliado) {
		
		return afiliadosrepo.save(afiliado);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		
		afiliadosrepo.deleteById(id);
	}
	
	

}
