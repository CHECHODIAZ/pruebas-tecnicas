package com.smetsalud.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smetsalud.app.entity.Afiliados;

@Repository
public interface AfiliadosRepository extends JpaRepository<Afiliados,Long> {
     
}
